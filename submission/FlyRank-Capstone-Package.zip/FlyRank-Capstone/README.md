# FlyRank Search Intelligence Capstone

## Refresh / Content Opportunity Scoring

This capstone studies whether a repeatable scoring approach can prioritize pages for content review using safe, anonymized search-performance signals.

### Research question
Can a transparent scoring model prioritize pages for content-refresh review more consistently than an ad-hoc manual process?

### Documented evidence
- Dataset: 30,000 anonymized page records.
- Baseline action score used search opportunity, 90-day impressions, CTR opportunity, content age, and average position.
- Documented baseline Precision@20: 0.900.
- Documented baseline Precision@50: 0.680.
- A depth-2 decision-tree comparison was explored, but the captured work does not support claiming a validated model improvement over the baseline.

### Honest framing
The results are decision-support evidence, not proof of Google's ranking algorithm or causal evidence that refreshing a page will improve traffic.

## Paper
The research paper is in `paper/index.html`.

Before submission, deploy `paper/index.html` and put the exact deployed URL as the only line in:

`submission/paper_url.txt`

## Reproducibility
The `work/` folder contains lightweight reconstruction notebooks documenting the baseline, model comparison, validation audit, action playbook, and capstone narrative. These are intentionally explicit about which results are documented versus not reproduced.

## Data credit
Built on the FlyRank ML Internship dataset.
